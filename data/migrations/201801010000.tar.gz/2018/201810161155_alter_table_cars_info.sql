ALTER TABLE "public"."cars_info" ADD COLUMN "service_battery" timestamp with time zone;
ALTER TABLE "public"."cars_info" ADD COLUMN "crash" integer;