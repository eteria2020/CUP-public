ALTER TABLE "public"."cars_info" ADD COLUMN "android_iccid" text;
ALTER TABLE "public"."cars_info" ADD COLUMN "gprs_iccid" text;