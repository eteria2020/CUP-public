INSERT INTO mails VALUES (107, 'Share''n Go B2B - Carta di credito, notifica scadenza', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>SHARE&#39;NGO B2B Azienda disattivata</title>
		<link href=''https://fonts.googleapis.com/css?family=Lato:400,900'' rel=''stylesheet'' type=''text/css''/>
	</head>

	<body style="text-decoration:none !important;">
		<table width="500" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="500" height="45"><a href="http://site.sharengo.it" target="_blank"><img src="http://www.sharengo.it/images/mails/Sharengo_Header_LOGO_500x45.gif" width="500" height="45" alt="logo_sharengo" /></a></td></tr>
			<tr>
				<td  width="500" height="158"><a href="http://site.sharengo.it" target="_blank"><img src="http://www.sharengo.it/images/mails/VISUAL_benvenuto.gif" width="500" height="158" alt="visual_sharengo" /></a></td></tr>
			<tr><td width="500" height="20"></td></tr>
			<tr>
				<td>
					<!-- TABELLA TESTO -->
					<table width="500" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td width="10"></td>
							<td width="480" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:14px; color:#333;  font-weight:regular; line-height:20px;text-align:justify">
								<span style="font-size:22px; color:#08bd53; font-weight:bold;">SHARE&#39;NGO AZIENDE</span><br /><br />
								Gentile %1$s,<br /><br />
								abbiamo rilevato che la <u>carta di credito &egrave; prossima alla scdenza</u>. <br /><br />
								Per inserire i dati di una nuova carta, occorre:<br />
								<ul style="color:#08bd53">
									<li><span style="color:#333;">effettuare il <a href="http://business.sharengo.it/user/login" target="_blank" style="color:#08bd53; text-decoration:none;">login in</a> nell&#39; Area Riservata con i dati del profilo aziendale; <br /> </span></li>
									<li><span style="color:#333;">cliccare sul pulsante &quot;<strong>cambia carta</strong>&quot;.</span></li>
								</ul>
								In caso di dubbi o difficolt&agrave;, invia una mail a  <a href="mailto:servizioclienti@sharengo.eu" target="_blank" style="color:#08bd53; text-decoration:none;">servizioclienti@sharengo.eu</a>. <br /><br />
								Cordiali saluti.<br />
							</td>
							<td width="10"></td>
						</tr>
					</table>
					<!-- FINE TABELLA TESTO -->
				</td>
			</tr>
			<tr>
				<td></td>
			</tr>
			<tr><td width="500" height="20"></td></tr>
			<tr>
				<td  width="500" height="40" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:center;"><img src="http://www.sharengo.it/images/mails/Sharengo_Footer_TEAM_500x40.gif" width="500" height="40" alt="sharengo_team" /></td>
			</tr>
			<tr>
				<td  width="500" height="40" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:center;">
					Info e regolamento su <a href="http://site.sharengo.it" target="_blank" style="color:#08bd53; text-decoration:none;">www.sharengo.it</a>
				</td>
			</tr>
			<tr>
				<td  width="500" height="80" bgcolor="#1c2429" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:left;">
					<!-- TABELLA FOOTER -->
					<table width="500" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td width="10"></td>
							<td style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#08bd53;  font-weight:regular; text-align:left; vertical-align:bottom;">SEGUICI SU</td>
							<td></td>
							<td width="10"></td>
						</tr>
						<tr>
							<td width="10"></td>
							<td>
								<!-- TABELLA SOCIAL -->
								<table width="175" border="0" cellspacing="0" cellpadding="0">
									<tr>
										<td><a href="https://www.facebook.com/ShareNGo.eu" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_FB.gif" width="30" height="30" alt="sharengo facebook" /></a></td>
										<td width="5"></td>
										<td><a href="https://twitter.com/share_n_go" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_TW.gif" width="30" height="30" alt="sharengo twitter" /></a></td>
										<td width="5"></td>
										<td><a href="https://www.linkedin.com/company/share''ngo" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_IN.gif" width="30" height="30" alt="sharengo in" /></a></td>
										<td width="5"></td>
										<td><a href="https://www.facebook.com/ShareNGo.eu" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_LikeFB.gif" width="70" height="30" alt="sharengo facebook" /></a></td>
									</tr>
								</table>
								<!-- FINE TABELLA SOCIAL -->
							</td>
							<td style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#999;  font-weight:regular; text-align:right;">Servizio clienti <span style="color:#ccc;">0586 1975772</span><br/>
							&copy; Share&#39;ngo CS Group Spa 2016</td>
							<td width="10"></td>
						</tr>
					</table>
					<!-- FINE TABELLA FOOTER -->
				</td>
			</tr>
		</table>
	</body>
</html>', true, 'it', 107);

INSERT INTO mails VALUES (108, 'Share''n Go B2B - Carta di credito scaduta', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>SHARE&#39;NGO B2B Azienda disattivata</title>
		<link href=''https://fonts.googleapis.com/css?family=Lato:400,900'' rel=''stylesheet'' type=''text/css''/>
	</head>

	<body style="text-decoration:none !important;">
		<table width="500" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="500" height="45"><a href="http://site.sharengo.it" target="_blank"><img src="http://www.sharengo.it/images/mails/Sharengo_Header_LOGO_500x45.gif" width="500" height="45" alt="logo_sharengo" /></a></td></tr>
			<tr>
				<td  width="500" height="158"><a href="http://site.sharengo.it" target="_blank"><img src="http://www.sharengo.it/images/mails/VISUAL_benvenuto.gif" width="500" height="158" alt="visual_sharengo" /></a></td></tr>
			<tr><td width="500" height="20"></td></tr>
			<tr>
				<td>
					<!-- TABELLA TESTO -->
					<table width="500" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td width="10"></td>
							<td width="480" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:14px; color:#333;  font-weight:regular; line-height:20px;text-align:justify">
								<span style="font-size:22px; color:#08bd53; font-weight:bold;">SHARE&#39;NGO AZIENDE</span><br /><br />
								Gentile %1$s,<br /><br />
								abbiamo dovuto sospendere l&#39;account della sua azienda in quanto la <u>carta di credito risulta scaduta</u>. <br /><br />
								Per abilitare nuovamente il profilo aziendale, occorre: <br />
								<ul style="color:#08bd53">
									<li><span style="color:#333;">effettuare il <a href="http://business.sharengo.it/user/login" target="_blank" style="color:#08bd53; text-decoration:none;">login in</a> nell&#39; Area Riservata con i dati del profilo aziendale; <br /> </span></li>
									<li><span style="color:#333;">cliccare sul pulsante &quot;<strong>cambia carta</strong>&quot;.</span></li>
								</ul>

								Una volta cambiata la carta, se i pagamenti andranno a buon fine, l&#39;account aziendale verr&agrave; riattivato e tutti i driver potranno continuare ad utilizzare le Share&#39;ngo per i loro spostamenti aziendali.<br /><br />
								In caso di dubbi o difficolt&agrave;, invia una mail a  <a href="mailto:servizioclienti@sharengo.eu" target="_blank" style="color:#08bd53; text-decoration:none;">servizioclienti@sharengo.eu</a>. <br /><br />
								Cordiali saluti.<br />
							</td>
							<td width="10"></td>
						</tr>
					</table>
					<!-- FINE TABELLA TESTO -->
				</td>
			</tr>
			<tr>
				<td></td>
			</tr>
			<tr><td width="500" height="20"></td></tr>
			<tr>
				<td  width="500" height="40" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:center;"><img src="http://www.sharengo.it/images/mails/Sharengo_Footer_TEAM_500x40.gif" width="500" height="40" alt="sharengo_team" /></td>
			</tr>
			<tr>
				<td  width="500" height="40" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:center;">
					Info e regolamento su <a href="http://site.sharengo.it" target="_blank" style="color:#08bd53; text-decoration:none;">www.sharengo.it</a>
				</td>
			</tr>
			<tr>
				<td  width="500" height="80" bgcolor="#1c2429" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:left;">
					<!-- TABELLA FOOTER -->
					<table width="500" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td width="10"></td>
							<td style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#08bd53;  font-weight:regular; text-align:left; vertical-align:bottom;">SEGUICI SU</td>
							<td></td>
							<td width="10"></td>
						</tr>
						<tr>
							<td width="10"></td>
							<td>
								<!-- TABELLA SOCIAL -->
								<table width="175" border="0" cellspacing="0" cellpadding="0">
									<tr>
										<td><a href="https://www.facebook.com/ShareNGo.eu" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_FB.gif" width="30" height="30" alt="sharengo facebook" /></a></td>
										<td width="5"></td>
										<td><a href="https://twitter.com/share_n_go" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_TW.gif" width="30" height="30" alt="sharengo twitter" /></a></td>
										<td width="5"></td>
										<td><a href="https://www.linkedin.com/company/share''ngo" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_IN.gif" width="30" height="30" alt="sharengo in" /></a></td>
										<td width="5"></td>
										<td><a href="https://www.facebook.com/ShareNGo.eu" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_LikeFB.gif" width="70" height="30" alt="sharengo facebook" /></a></td>
									</tr>
								</table>
								<!-- FINE TABELLA SOCIAL -->
							</td>
							<td style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#999;  font-weight:regular; text-align:right;">Servizio clienti <span style="color:#ccc;">0586 1975772</span><br/>
							&copy; Share&#39;ngo CS Group Spa 2016</td>
							<td width="10"></td>
						</tr>
					</table>
					<!-- FINE TABELLA FOOTER -->
				</td>
			</tr>
		</table>
	</body>
</html>', true, 'it', 108);