UPDATE mails SET content ='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>SHARE''NGO</title>
        <link href=''https://fonts.googleapis.com/css?family=Lato:400,900'' rel=''stylesheet'' type=''text/css''></link>
    </head>

    <body style="text-decoration:none !important;">
        <table width="500" border="0" cellspacing="0" cellpadding="0">
            <tr>
                <td width="500" height="45"><a href="http://site.sharengo.it" target="_blank"><img src="http://www.sharengo.it/images/mails/Sharengo_Header_LOGO_500x45.gif" width="500" height="45" alt="logo_sharengo" /></a></td></tr>
            <tr>
                <td  width="500" height="158"><a href="http://site.sharengo.it" target="_blank"><img src="http://www.sharengo.it/images/mails/VISUAL_sconto_scadenza.gif" width="500" height="158" alt="visual_sharengo" /></a></td></tr>
            <tr><td width="500" height="20"></td></tr>
            <tr>
                <td>
                    <!-- TABELLA TESTO -->
                    <table width="500" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="10"></td>
                            <td width="480" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:14px; color:#333;  font-weight:regular; line-height:20px; text-align: justify">
                                Ciao %1$s,<br />
                                tra una settimana scadr&agrave; la validit&agrave; del tuo sconto personale.<br /><br />
                                Ma Share&#39;ngo continua a premiare il tuo bisogno di mobilit&agrave; e la tua partecipazione alla sharing economy. Tra una settimana riceverai una mail che ti spiegher&agrave; come verr&agrave; rinnovato il tuo sconto. <br /><br />
                                Ti ricordiamo inoltre che con i Pacchetti Minuti che trovi in Area Riservata nella sezione <strong>&quot;Promo e Pacchetti&quot;</strong> (corri fino a <strong>0,22 &euro;/min</strong>) e con una novit&agrave; introdotta quest&#39;anno: i <strong>PUNTI OSSIGENO</strong>. <br /><br />
                                I Punti Ossigeno si cumuleranno ad ogni corsa che farai e il tuo saldo punti sar&agrave; sempre visibile in App e nella tua Area Riservata. Potrai convertire i tuoi PUNTI OSSIGENO in Pacchetti Minuti in Area Riservata. Al momento &egrave; gi&agrave; disponibile il primo Pacchetto da&nbsp;<strong>1.400 punti</strong>&nbsp;per&nbsp;<strong>25 minuti</strong>. <br /><br />
                                Grazie per essere stato con noi questo anno in cui abbiamo fatto tanta strada insieme <strong>risparmiando pi&ugrave; di 80 tonnellate di emissione di CO2</strong> nell&#39;aria delle nostre citt&agrave;.<br /><br />
                                Grazie e a presto.<br /><br />
                                Un caro saluto, 
                            </td>
                            <td width="10"></td>
                        </tr>
                    </table>
                            <!-- FINE TABELLA TESTO -->
                </td>
            </tr>
                <tr><td width="500" height="20"></td></tr>
                <tr>
                    <td  width="500" height="40" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:center;"><img src="http://www.sharengo.it/images/mails/Sharengo_Footer_TEAM_500x40.gif" width="500" height="40" alt="sharengo_team" />
                    </td>
                </tr>
                <tr>
                    <td  width="500" height="40" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:center;">
                        Info e regolamento su <a href="http://site.sharengo.it" target="_blank" style="color:#08bd53; text-decoration:none;">www.sharengo.it</a>
                    </td>
                </tr>
                <tr>
                    <td  width="500" height="80" bgcolor="#1c2429" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:left;">
                        <!-- TABELLA FOOTER -->
                        <table width="500"  border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td width="10"></td>
                                <td style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#08bd53;  font-weight:regular; text-align:left; vertical-align:bottom;">SEGUICI SU</td>
                                <td></td>
                                <td width="10"></td>
                            </tr>
                            <tr>
                                <td width="10"></td>
                                <td>
                                    <!-- TABELLA SOCIAL -->
                                    <table width="100"  border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td><a href="https://www.facebook.com/ShareNGo.eu" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_FB.gif" width="30" height="30" alt="sharengo facebook" /></a></td>
                                            <td width="5"></td>
                                            <td><a href="https://twitter.com/share_n_go" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_TW.gif" width="30" height="30" alt="sharengo twitter" /></a></td>
                                            <td width="5"></td>
                                            <td><a href="https://www.linkedin.com/company/share&#39;ngo" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_IN.gif" width="30" height="30" alt="sharengo in" /></a></td>
                                        </tr></table>
                                    <!-- FINE TABELLA SOCIAL -->
                                </td>
                                <td style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#999;  font-weight:regular; text-align:right;">Servizio clienti <span style="color:#ccc;">0586 1975772</span><br/>
                                    © Share’ngo CS Group Spa 2016</td>
                                <td width="10"></td>
                            </tr>
                        </table>
                        <!-- FINE TABELLA FOOTER -->
                </td>
            </tr>
        </table>
    </body>
</html>' WHERE category=17;

UPDATE mails 
SET 
subject='Share’ngo: Sconto rinnovato', 
content ='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>SHARE''NGO</title>
        <link href=''https://fonts.googleapis.com/css?family=Lato:400,900'' rel=''stylesheet'' type=''text/css''></link>
    </head>

    <body style="text-decoration:none !important;">
        <table width="500" border="0" cellspacing="0" cellpadding="0">
            <tr>
                <td width="500" height="45"><a href="http://site.sharengo.it" target="_blank"><img src="http://www.sharengo.it/images/mails/Sharengo_Header_LOGO_500x45.gif" width="500" height="45" alt="logo_sharengo" /></a></td></tr>
            <tr>
                <td  width="500" height="158"><a href="http://site.sharengo.it" target="_blank"><img src="http://www.sharengo.it/images/mails/VISUAL_un_anno_insieme.gif" width="500" height="158" alt="visual_sharengo" /></a></td></tr>
            <tr><td width="500" height="20"></td></tr>
            <tr>
                <td>
                    <!-- TABELLA TESTO -->
                    <table width="500" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="10"></td>
                            <td width="480" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:14px; color:#333;  font-weight:regular; line-height:20px; text-align: justify">		  
                                Ciao %1$s,<br />
                                &egrave; scaduto lo sconto che avevi ottenuto in precedenza. Per vedere di nuovo riconosciuto il tuo bisogno di mobilit&agrave; e premiata la tua partecipazione alla sharing economy, Share&#39;ngo ti applicher&agrave; in automatico <strong>un nuovo sconto del 14 &#37; </strong>, portando la tua tariffa a 0,24 &euro;/min per un intero anno.<br /><br />
                                Per ottenere la tua nuova tariffa non devi fare nulla, sar&agrave; applicata in automatico dal sistema. Domani puoi accedere alla tua area personale per controllare.<br /><br />
                                Buon viaggio con Share&#39;ngo! <br /><br />
                                Un caro saluto, 
                            </td>
                            <td width="10"></td>
                        </tr>
                    </table>
                    <!-- FINE TABELLA TESTO -->
                </td>
            </tr>
            <tr><td width="500" height="20"></td></tr>
            <tr>
                <td  width="500" height="40" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:center;"><img src="http://www.sharengo.it/images/mails/Sharengo_Footer_TEAM_500x40.gif" width="500" height="40" alt="sharengo_team" /></td></tr>
            <tr>
                <td  width="500" height="40" bgcolor="#FFFFFF" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:center;">Info e regolamento su <a href="http://site.sharengo.it" target="_blank" style="color:#08bd53; text-decoration:none;">www.sharengo.it</a></td></tr>
            <tr>
                <td  width="500" height="80" bgcolor="#1c2429" style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#333;  font-weight:regular; text-align:left;">
                    <!-- TABELLA FOOTER -->
                    <table width="500" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="10"></td>
                            <td style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#08bd53;  font-weight:regular; text-align:left; vertical-align:bottom;">SEGUICI SU</td>
                            <td></td>
                            <td width="10"></td>
                        </tr>
                        <tr>
                            <td width="10"></td>
                            <td>
                                <!-- TABELLA SOCIAL -->
                                <table width="100"  border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td><a href="https://www.facebook.com/ShareNGo.eu" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_FB.gif" width="30" height="30" alt="sharengo facebook" /></a></td>
                                        <td width="5"></td>
                                        <td><a href="https://twitter.com/share_n_go" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_TW.gif" width="30" height="30" alt="sharengo twitter" /></a></td>
                                        <td width="5"></td>
                                        <td><a href="https://www.linkedin.com/company/share&#39;ngo" target="_blank" style="color:#08bd53; text-decoration:none;"><img src="http://www.sharengo.it/images/mails/Sharengo_Social_IN.gif" width="30" height="30" alt="sharengo in" /></a></td>
                                    </tr>
                                </table>
                                <!-- FINE TABELLA SOCIAL -->
                            </td>
                            <td style="font-family:''Lato'', arial, sans-serif; font-size:12px; color:#999;  font-weight:regular; text-align:right;">Servizio clienti <span style="color:#ccc;">0586 1975772</span><br/>
                            © Share’ngo CS Group Spa 2016</td>
                            <td width="10"></td>
                        </tr>
                    </table>
                    <!-- FINE TABELLA FOOTER -->
                </td>
            </tr>
        </table>
    </body>
</html>' WHERE category=18;