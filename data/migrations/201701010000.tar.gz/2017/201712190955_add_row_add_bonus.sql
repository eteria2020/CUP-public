INSERT INTO add_bonus (description, type)
VALUES ('Bonus Babbo Natale', 'min');