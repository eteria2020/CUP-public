CREATE TABLE add_bonus (
    id SERIAL PRIMARY KEY,
    description text NOT NULL
);