ALTER TYPE reservations_archive_reason ADD VALUE 'ALARM-OFF';
