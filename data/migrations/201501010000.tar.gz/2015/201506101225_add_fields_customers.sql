ALTER TABLE customers ADD gold_list BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE customers ADD maintainer BOOLEAN NOT NULL DEFAULT false;