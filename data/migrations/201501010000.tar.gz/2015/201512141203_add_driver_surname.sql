ALTER TABLE customers ADD driver_license_surname VARCHAR(255) DEFAULT NULL;
ALTER TABLE customers ADD driver_license_firstname VARCHAR(255) DEFAULT NULL;