CREATE TABLE countries (
    code varchar(2) PRIMARY KEY,
    name text
);

