ALTER TABLE reservations ALTER customer_id DROP NOT NULL;
