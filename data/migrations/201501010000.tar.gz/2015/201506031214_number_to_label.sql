ALTER TABLE cars RENAME "number" to label;
ALTER TABLE cars ALTER label TYPE text;