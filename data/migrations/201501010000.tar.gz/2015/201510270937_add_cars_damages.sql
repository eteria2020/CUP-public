CREATE TABLE cars_damages (name TEXT NOT NULL, PRIMARY KEY(name));
