ALTER TABLE reservations ALTER sent_ts DROP NOT NULL;
