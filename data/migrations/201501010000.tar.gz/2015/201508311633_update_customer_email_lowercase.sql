UPDATE customers SET email = lower(email);
