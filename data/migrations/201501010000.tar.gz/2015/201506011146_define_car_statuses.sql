ALTER TYPE car_status ADD VALUE 'operative';
ALTER TYPE car_status ADD VALUE 'not operative';
ALTER TYPE car_status ADD VALUE 'maintenance';