ALTER TABLE customers DROP COLUMN IF EXISTS commercial_condition1;
ALTER TABLE customers DROP COLUMN IF EXISTS commercial_condition2;
