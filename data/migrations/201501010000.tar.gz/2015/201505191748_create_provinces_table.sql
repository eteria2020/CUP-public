CREATE TABLE provinces (
    code varchar(2) NOT NULL,
    name text DEFAULT NULL,
    PRIMARY KEY(code));
