-- ALTER TABLE customers ADD CONSTRAINT email_uk UNIQUE (email);

-- ALTER TABLE customers ADD CONSTRAINT tax_code_uk UNIQUE (tax_code);
