ALTER TABLE trip_payments_canceled
ALTER COLUMN first_payment_try_ts
DROP NOT NULL;
