ALTER TABLE trip_payments ADD UNIQUE (trip_id);
