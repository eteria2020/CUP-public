DELETE FROM cars_damages WHERE name='Parabrezza';
DELETE FROM cars_damages WHERE name='Lunotto posteriore';
DELETE FROM cars_damages WHERE name='Gomma forata';

INSERT INTO cars_damages (name) VALUES ('Tetto');
INSERT INTO cars_damages (name) VALUES ('Antenna');
INSERT INTO cars_damages (name) VALUES ('Sedile sin');
INSERT INTO cars_damages (name) VALUES ('Sedile des');
INSERT INTO cars_damages (name) VALUES ('Cruscotto');
INSERT INTO cars_damages (name) VALUES ('Aria condizionata');
INSERT INTO cars_damages (name) VALUES ('Volante');
INSERT INTO cars_damages (name) VALUES ('Clacson');
INSERT INTO cars_damages (name) VALUES ('Cofano');
INSERT INTO cars_damages (name) VALUES ('Luce di cortesia');
INSERT INTO cars_damages (name) VALUES ('Finestrino des');
INSERT INTO cars_damages (name) VALUES ('Finestrino sin');
INSERT INTO cars_damages (name) VALUES ('Specchietto interno');