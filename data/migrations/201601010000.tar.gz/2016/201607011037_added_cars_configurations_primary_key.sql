ALTER TABLE cars_configurations
    ADD CONSTRAINT cars_configurations_pkey PRIMARY KEY (id);