ALTER TABLE customers_bonus_packages
    ADD COLUMN display_priority INTEGER NOT NULL DEFAULT 0;