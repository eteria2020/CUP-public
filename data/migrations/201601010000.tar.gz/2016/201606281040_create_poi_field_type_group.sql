ALTER TABLE pois
    ADD COLUMN type_group text;